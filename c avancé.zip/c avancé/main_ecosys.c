#include <assert.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <strings.h>
#include "ecosys.h"

float p_ch_dir=0.01;
float p_reproduce_proie=0.1;
float p_reproduce_predateur=0.2;
int temps_repousse_herbe=-15;


#define NB_PROIES 20
#define NB_PREDATEURS 20
#define T_WAIT 40000


/* Parametres globaux de l'ecosysteme (externes dans le ecosys.h)*/


int main(void) {
 
  /* A completer. Part 2:
   * exercice 4, questions 2 et 4 
   * exercice 6, question 2*/
   Animal *liste_animal = NULL;
   srand(time(NULL));
   ajouter_animal(0, 10, 10, &liste_animal);
   ajouter_animal(15, 35, 10, &liste_animal);
   /* exercice 7, question 3
   * exercice 8, question 1
   */
   //TME 3 exercice 4 question 1
   Animal *a = creer_animal(0,0,10);
   a->dir[0]=-1;
   a->dir[1]=-2;
   bouger_animaux(a);
   printf("apres avoir deplacer l'animal : x=%d  y=%d dir[0]=%d  dir[1]=%d energie=%.2f \n",a->x,a->y,a->dir[0],a->dir[1],a->energie);
   a->dir[0]=2;
   a->dir[1]=4;
   bouger_animaux(a);
   printf("apres avoir deplacer l'animal : x=%d  y=%d dir[0]=%d  dir[1]=%d energie=%.2f \n",a->x,a->y,a->dir[0],a->dir[1],a->energie);
   //TME 3 exercice 4 question 2
   printf("Nombre de prédateurs : %d\n",compte_animal_rec(liste_animal));
   reproduce(&liste_animal,1);
   printf("Nombre de prédateurs : %d\n",compte_animal_rec(liste_animal));
   reproduce(&liste_animal,1);
   printf("Nombre de prédateurs : %d\n",compte_animal_rec(liste_animal));
   reproduce(&liste_animal,1);
   printf("Nombre de prédateurs : %d\n",compte_animal_rec(liste_animal));
   reproduce(&liste_animal,1);
   printf("Nombre de prédateurs : %d\n",compte_animal_rec(liste_animal));
   reproduce(&liste_animal,1);
   printf("Nombre de prédateurs : %d\n",compte_animal_rec(liste_animal));
   //TME 3 exercice 5 question 2
   /*Animal *liste_proie = NULL;
   for(int i=0;i<20;i++){
  	ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,10,&liste_proie);
   }
   int i=0;
   while(liste_proie!=NULL && i<200){
   	rafraichir_proies(&liste_proie,0);
   	afficher_ecosys(liste_proie, NULL);
   	usleep(500000);//attend 0.5 secondes
   	i++;
   }
   liste_proie = liberer_liste_animaux(liste_proie);
   printf("Fin des mises à jour après %d itérations.\n", i);*/
   
   //TME 3 exercice 6 question 3
   /*Animal *liste_proie = NULL;
   Animal *liste_predateur = NULL;
   for(int i=0;i<20;i++){
  	ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,10,&liste_proie);
  	ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,10,&liste_predateur);
   }
   int i=0;
   int tab1[SIZE_X][SIZE_Y];
   while(liste_proie!=NULL && liste_predateur!=NULL && i<200){
   	rafraichir_proies(&liste_proie,tab1);
   	rafraichir_predateurs(&liste_predateur,&liste_proie);
   	afficher_ecosys(liste_proie, liste_predateur);
   	usleep(500000);
   	i++;
   }
   liste_proie = liberer_liste_animaux(liste_proie);
   liste_predateur = liberer_liste_animaux(liste_predateur);
   printf("Fin des mises à jour après %d itérations.\n", i);*/
   
   //TME 3 exercice 7 question 1
   /*Animal *liste_proie = NULL;
   Animal *liste_predateur = NULL;
   for(int i=0;i<20;i++){
  	ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,10,&liste_proie);
  	ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,10,&liste_predateur);
  }
   int monde[SIZE_X][SIZE_Y];
   for(int i=0;i<SIZE_X;i++){
   	for(int j=0;j<SIZE_Y;j++){
   		monde[i][j]=0;
   	}
   }
   int i=0;
   while(liste_proie!=NULL && liste_predateur!=NULL && i<200){
   	rafraichir_proies(&liste_proie,monde);
   	rafraichir_predateurs(&liste_predateur,&liste_proie);
   	rafraichir_monde(monde);
   	afficher_ecosys(liste_proie, liste_predateur);
   	usleep(500000);
   	i++;
   }
   liste_proie = liberer_liste_animaux(liste_proie);
   liste_predateur = liberer_liste_animaux(liste_predateur);
   printf("Fin des mises à jour après %d itérations.\n", i);*/
   
   //TME 3 ecercice 8 question 1
   Animal *liste_proie = NULL;
   Animal *liste_predateur = NULL;
   for(int i=0;i<20;i++){
  	ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,10,&liste_proie);
  	ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,10,&liste_predateur);
  }
   int monde[SIZE_X][SIZE_Y];
   for(int i=0;i<SIZE_X;i++){
   	for(int j=0;j<SIZE_Y;j++){
   		monde[i][j]=0;
   	}
   }
   FILE *fichier = fopen("Evol_Pop.txt", "w");
    if (fichier == NULL) {
        fprintf(stderr, "Erreur d'ouverture du fichier.\n");
        return EXIT_FAILURE;
    }
   int i=0;
   while(liste_proie!=NULL && liste_predateur!=NULL && i<200){
   	rafraichir_proies(&liste_proie,monde);
   	rafraichir_predateurs(&liste_predateur,&liste_proie);
   	rafraichir_monde(monde);
   	afficher_ecosys(liste_proie, liste_predateur);
   	usleep(T_WAIT);
   	i++;
   	fprintf(fichier, "%d %d %d\n", i, compte_animal_rec(liste_proie), compte_animal_rec(liste_predateur));
   }
   liste_proie = liberer_liste_animaux(liste_proie);
   liste_predateur = liberer_liste_animaux(liste_predateur);
   printf("Fin des mises à jour après %d itérations.\n", i);
   fclose(fichier);
   
    FILE *gnuplot = popen("gnuplot -persistent", "w");
    if (gnuplot == NULL) {
        perror("Erreur lors de l'ouverture de gnuplot");
        return 1;
    }
	//TME 3 exercice 8 question 1:
    // Envoyer des commandes à gnuplot
    fprintf(gnuplot, "set title 'Simulation ecosystème'\n");
    fprintf(gnuplot, "plot 'Evol_Pop.txt' using 1:2 with lines title 'proies'\n");
    fprintf(gnuplot, "replot 'Evol_Pop.txt' using 1:3 with lines title 'predateurs'\n");
   
    // Fermer le pipe
    pclose(gnuplot);


   //q 6
   /*en tappent la comande valgrind ./ecosys (ecosys est le nom de l'éxecutable de ce code) 
   on obtient un affichage qui indique qu'il y'a une fuite mémoire dans ce code et pour la régler on doit
   liberer l'espace mémoire alouée pas la liste liste_animal et on fait cela ainsi : */
   liste_animal=liberer_liste_animaux(liste_animal);
   free(a);
   return 0;
}

