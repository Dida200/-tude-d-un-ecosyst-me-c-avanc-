//Exercice 6 question 3
#include <assert.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <strings.h>
#include "ecosys.h"

float p_ch_dir=0.01;
float p_reproduce_proie=0.1;
float p_reproduce_predateur=0.2;
int temps_repousse_herbe=-15;

#define NB_PROIES 20
#define NB_PREDATEURS 20
#define T_WAIT 40000
int main(void){
	Animal *liste_proie = NULL;
  	Animal *liste_predateur = NULL;
  	srand(time(NULL));
  	for(int i=0;i<20;i++){
  		ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,10,&liste_proie);
  		ajouter_animal(rand()%SIZE_X,rand()%SIZE_Y,10,&liste_predateur);
  	}
  	printf("Nombre de proies : %d\n", compte_animal_rec(liste_proie));
        printf("Nombre de prédateurs : %d\n",compte_animal_rec(liste_predateur));
        afficher_ecosys(liste_proie, liste_predateur);
        //q 7(suite)
        Animal *ap = creer_animal(2,5, 10);
        Animal *apred = creer_animal(3,4, 10);
        liste_proie=ajouter_en_tete_animal(liste_proie,ap);
        liste_predateur=ajouter_en_tete_animal(liste_predateur,apred);
        printf("Nombre de proies : %d\n", compte_animal_rec(liste_proie));//on a cet affichage : Nombre de proies : 21
        printf("Nombre de prédateurs : %d\n",compte_animal_rec(liste_predateur));//on a cet affichage : Nombre de predateurs : 21
    	enlever_animal(&liste_proie,ap);
    	enlever_animal(&liste_predateur,apred);
    	printf("Nombre de proies : %d\n", compte_animal_rec(liste_proie));//on a cet affichage : Nombre de proies : 20
        printf("Nombre de prédateurs : %d\n",compte_animal_rec(liste_predateur));//on a cet affichage : Nombre de predateurs : 20
	//TME 3 exercice 3 question1
	ecrire_ecosysteme("file.txt",liste_proie,liste_predateur);
	Animal *liste_proie2 = NULL;
  	Animal *liste_predateur2 = NULL;
  	lire_ecosysteme("file.txt",&liste_proie2,&liste_predateur2);
  	if (verifier_liste(liste_proie2,liste_proie)==1 && verifier_liste(liste_predateur2,liste_predateur)==1){
  		printf("les ecosystemes ecrits et lus sont les mémes\n");
  	}
  	else{
  		printf("les ecosystemes ecrits et lus ne sont pas les mémes\n");
  	}
  	ecrire_ecosysteme("file1.txt",liste_proie2,liste_predateur2);//pour comparer visuellement les listes
  	liste_proie2=liberer_liste_animaux(liste_proie2);
        liste_predateur2=liberer_liste_animaux(liste_predateur2);
        
        //q 5
        liste_proie=liberer_liste_animaux(liste_proie);
        liste_predateur=liberer_liste_animaux(liste_predateur);
 
    	//q 6
    	/*en tappent la comande valgrind ./main_tests2 dans le terminal on obtient cette affichage  ==461788== HEAP SUMMARY:
==461788==     in use at exit: 0 bytes in 0 blocks
==461788==   total heap usage: 41 allocs, 41 frees, 2,304 bytes allocated
==461788== 
==461788== All heap blocks were freed -- no leaks are possible
==461788== 
==461788== For lists of detected and suppressed errors, rerun with: -s
==461788== ERROR SUMMARY: 0 errors from 0 contexts (suppressed: 0 from 0)
 ce qui indique qu'il y'a pas de fuite de mémoire dans notre programme */
 
	return 0;
  
}
