#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "ecosys.h"
#include <string.h>

/* PARTIE 1*/
/* Fourni: Part 1, exercice 4, question 2 */
Animal *creer_animal(int x, int y, float energie) {
  Animal *na = (Animal *)malloc(sizeof(Animal));
  assert(na);
  na->x = x;
  na->y = y;
  na->energie = energie;
  na->dir[0] = rand() % 3 - 1;
  na->dir[1] = rand() % 3 - 1;
  na->suivant = NULL;
  return na;
}


/* Fourni: Part 1, exercice 4, question 3 */
Animal *ajouter_en_tete_animal(Animal *liste, Animal *animal) {
  assert(animal);
  assert(!animal->suivant);
  animal->suivant = liste;
  return animal;
}

/* A faire. Part 1, exercice 6, question 2 */
void ajouter_animal(int x, int y,  float energie, Animal **liste_animal) {
	assert(x>=0 && x<SIZE_X);
	assert(y>=0 && y<SIZE_Y);
	*liste_animal=ajouter_en_tete_animal(*liste_animal,creer_animal(x,y,energie));
	/*A Completer*/
}

/* A Faire. Part 1, exercice 5, question 5 */
void enlever_animal(Animal **liste, Animal *animal) {
  /*A Completer*/
  if (*liste==NULL || animal==NULL){
  	return ;
  }
  Animal *tmp=*liste;
  if (tmp==animal){
  	*liste=tmp->suivant;
  	free(tmp);
  	return ;
  }
  while(tmp->suivant!=NULL){
  	if (tmp->suivant==animal){
  		Animal *tmp2=tmp->suivant;
  		tmp->suivant =tmp->suivant->suivant;
  		free(tmp2);
  		return;
  	}
  	tmp=tmp->suivant;
  }
  return ;
}
/* A Faire. Part 1, exercice 6, question 7 */
Animal* liberer_liste_animaux(Animal *liste) {
   /*A Completer*/
	Animal *tmp;
	while(liste!=NULL){
		tmp=liste;
		liste=liste->suivant;
		free(tmp);
	}
	return NULL;
}

/* Fourni: part 1, exercice 4, question 4 */
unsigned int compte_animal_rec(Animal *la) {
  if (!la) return 0;
  return 1 + compte_animal_rec(la->suivant);
}

/* Fourni: part 1, exercice 4, question 4 */
unsigned int compte_animal_it(Animal *la) {
  int cpt=0;
  while (la) {
    ++cpt;
    la=la->suivant;
  }
  return cpt;
}



/* Part 1. Exercice 5, question 1, ATTENTION, ce code est susceptible de contenir des erreurs... */
void afficher_ecosys(Animal *liste_proie, Animal *liste_predateur) {
	//ici le proble est les valeurs donner aux variaables i et j dans chaque boucle for , les tailles max on etait inversés
  unsigned int i, j;
  char ecosys[SIZE_X][SIZE_Y];
  Animal *pa=NULL;

  /* on initialise le tableau */
  for (i = 0; i < SIZE_X; ++i) {
    for (j = 0; j < SIZE_Y; ++j) {
      ecosys[i][j]=' ';
    }
  }

  /* on ajoute les proies */
  pa = liste_proie;
  while (pa) {
    ecosys[pa->x][pa->y] = '*';
    pa=pa->suivant;
  }

  /* on ajoute les predateurs */
  pa = liste_predateur;
  while (pa) {
      if ((ecosys[pa->x][pa->y] == '@') || (ecosys[pa->x][pa->y] == '*')) { /* proies aussi present */
        ecosys[pa->x][pa->y] = '@';
      } else {
        ecosys[pa->x][pa->y] = 'O';
      }
    pa = pa->suivant;
  }

  /* on affiche le tableau */
  printf("+");
  for (j = 0; j < SIZE_Y; ++j) {
    printf("-");
  }  
  printf("+\n");
  for (i = 0; i < SIZE_X; ++i) {
    printf("|");
    for (j = 0; j < SIZE_Y; ++j) {
      putchar(ecosys[i][j]);
    }
    printf("|\n");
  }
  printf("+");
  for (j = 0; j<SIZE_Y; ++j) {
    printf("-");
  }
  printf("+\n");
  int nbproie=compte_animal_it(liste_proie);
  int nbpred=compte_animal_it(liste_predateur);
  
  printf("Nb proies : %5d\tNb predateurs : %5d\n", nbproie, nbpred);

}


void clear_screen() {
  printf("\x1b[2J\x1b[1;1H");  /* code ANSI X3.4 pour effacer l'ecran */
}/*pour effacer l'écran du terminal et repositionner le curseur au coin supérieur gauche.*/

/* PARTIE 2*/

/* Part 2. Exercice 4, question 1 */
void bouger_animaux(Animal *la) {
    /*A Completer*/
	if (la==NULL){
		return ;
	}
	int new_x = la->x + la->dir[0];
    	int new_y = la->y + la->dir[1];

    	// Appliquer la toricité pour s'assurer que l'animal reste dans les limites
    	if (new_x < 0) {
        	new_x = SIZE_X + new_x;
    	} else if (new_x >= SIZE_X) {
        	new_x = new_x - SIZE_X;
    	}

    	if (new_y < 0) {
        	new_y = SIZE_Y + new_y;
    	} else if (new_y >= SIZE_Y) {
        	new_y = new_y - SIZE_Y;
    	}

    	// Mettre à jour les coordonnées de l'animal
    	la->x = new_x;
    	la->y = new_y;
}

/* Part 2. Exercice 4, question 3 */
void reproduce(Animal **liste_animal, float p_reproduce) {
   /*A Completer*/
	Animal *tmp=*liste_animal;
	while(tmp!=NULL){
		if (((float)rand() / RAND_MAX <= p_reproduce) && (tmp->energie>1)) {
			tmp->energie/=2;
			ajouter_animal(rand()%20,rand()%50,10,liste_animal);
		}
		tmp=tmp->suivant;
	}		
}


/* Part 2. Exercice 5, question 1 */
void rafraichir_proies(Animal **liste_proie, int monde[SIZE_X][SIZE_Y]) {
    /*A Completer*/
    	Animal *tmp=*liste_proie;
	while(tmp!=NULL){
		//TME 3 exercice 7 question 3
		if (monde[tmp->x][tmp->y]>=0){
			tmp->energie+=monde[tmp->x][tmp->y];
			monde[tmp->x][tmp->y]= temps_repousse_herbe;
		}
		//fin partie 2 exercice 7 question 3
		bouger_animaux(tmp);
		tmp->energie--;
		if (tmp->energie<0){
			enlever_animal(liste_proie,tmp);
		}
		tmp=tmp->suivant;
	}
	reproduce(liste_proie,p_reproduce_proie);	
}

/* Part 2. Exercice 6, question 1 */
Animal *animal_en_XY(Animal *l, int x, int y) {
    /*A Completer*/
	Animal *tmp=l;
	while(tmp!=NULL){
		if (tmp->x==x && tmp->y==y){
			return tmp;
		}
		tmp=tmp->suivant;
	}
  	return NULL;
} 

/* Part 2. Exercice 6, question 2 */
void rafraichir_predateurs(Animal **liste_predateur, Animal **liste_proie) {
   /*A Completer*/
	Animal *tmp=*liste_predateur;
	while(tmp!=NULL){
		bouger_animaux(tmp);
		tmp->energie--;
		if (tmp->energie<0){
			enlever_animal(liste_predateur,tmp);
		}
		if (animal_en_XY(*liste_proie,tmp->x,tmp->y)!=NULL){
			Animal *a=animal_en_XY(*liste_proie,tmp->x,tmp->y);
			tmp->energie+=a->energie;
			enlever_animal(liste_proie,a);
		}
		tmp=tmp->suivant;
	}
	reproduce(liste_predateur,p_reproduce_predateur);	
}

/* Part 2. Exercice 7, question 2 */
void rafraichir_monde(int monde[SIZE_X][SIZE_Y]){
   /*A Completer*/
	for (int x = 0; x < SIZE_X; x++) {
        	for (int y = 0; y < SIZE_Y; y++) {
            	// Incrémentation de la quantité d'herbe dans chaque case
            		monde[x][y]++;
        	}
        }
}
//TME3
//exercice 3 question 1
void ecrire_ecosysteme(const char *nom_fichier, Animal *liste_proie, Animal *liste_predateur) {
    // Fonction qui écrit les listes dans un fichier
    FILE *f = fopen(nom_fichier, "w"); // Ouvrir le fichier pour écrire
    if (f == NULL) {
        printf("Erreur lors de l'ouverture du fichier");
        return;
    }
    Animal *tmp = liste_proie;
    fprintf(f, "Proies:\n");
    while (tmp != NULL) {
        // Ecrire les caractéristiques de chaque proie
        fprintf(f, "%d %d %d %d %.2f\n",tmp->x, tmp->y,tmp->dir[0], tmp->dir[1], tmp->energie);
        tmp = tmp->suivant;
    }

    tmp = liste_predateur;
    fprintf(f, "Prédateurs:\n");
    while (tmp != NULL) {
        // Ecrire les caractéristiques de chaque prédateur
        fprintf(f, "%d %d %d %d %.2f\n",tmp->x, tmp->y,tmp->dir[0], tmp->dir[1], tmp->energie);
        tmp = tmp->suivant;
    }
    fclose(f);
}

void lire_ecosysteme(const char *nom_fichier, Animal **liste_proie, Animal **liste_predateur) {
    // Fonction qui lit les listes depuis un fichier et recrée les animaux
    FILE *f = fopen(nom_fichier, "r");
    if (f == NULL) {
        printf("Erreur lors de l'ouverture du fichier");
        return;
    }
    char type[20];
    int x, y,dir_x,dir_y;
    float energie;

    while (fscanf(f, "%s", type) != EOF) {
        if (strcmp(type, "Proies:") == 0) {
            // Lire les proies
            while (fscanf(f,  "%d %d %d %d %f", &x, &y, &dir_x, &dir_y, &energie) == 5) {
                Animal *a=creer_animal(x, y, energie);
                a->dir[0]=dir_x;
                a->dir[1]=dir_y;
                *liste_proie=ajouter_en_tete_animal(*liste_proie,a);
            }
        } else if (strcmp(type, "Prédateurs:") == 0) {
            // Lire les prédateurs
            while (fscanf(f,"%d %d %d %d %f", &x, &y, &dir_x, &dir_y, &energie) == 5) {
                Animal *a1=creer_animal(x, y, energie);
                a1->dir[0]=dir_x;
                a1->dir[1]=dir_y;
                *liste_predateur=ajouter_en_tete_animal(*liste_predateur,a1);
            }
        }
    }
    fclose(f);
}
int est_present(Animal *liste, Animal *animal) {
    Animal *tmp = liste;
    while (tmp != NULL) {
        if (tmp->x == animal->x && 
            tmp->y == animal->y && 
            tmp->dir[0] == animal->dir[0] && 
            tmp->dir[1] == animal->dir[1] && 
            tmp->energie == animal->energie) {
            return 1; // L'animal est présent
        }
        tmp = tmp->suivant;
    }
    return 0; // L'animal n'est pas présent
}

// Fonction pour vérifier si chaque élément de liste1 est présent dans liste2 et si les longueurs sont égales
int verifier_liste(Animal *liste1, Animal *liste2) {
    // Vérifier la longueur des listes
    int longueur1 = 0, longueur2 = 0;
    Animal *tmp1 = liste1, *tmp2 = liste2;

    while (tmp1 != NULL) {
        longueur1++;
        tmp1 = tmp1->suivant;
    }

    while (tmp2 != NULL) {
        longueur2++;
        tmp2 = tmp2->suivant;
    }

    // Si les longueurs sont différentes, retourner false
    if (longueur1 != longueur2) {
        return 0;
    }

    // Vérifier si chaque élément de liste1 est présent dans liste2
    tmp1 = liste1; // Réinitialiser tmp1 pour la vérification
    while (tmp1 != NULL) {
        if (est_present(liste2, tmp1)==0) {
            return 0; // Si un élément n'est pas présent, retourner false
        }
        tmp1 = tmp1->suivant;
    }

    return 1; // Toutes les vérifications réussies
}
